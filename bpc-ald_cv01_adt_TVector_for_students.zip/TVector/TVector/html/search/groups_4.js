var searchData=
[
  ['5_2e_20univerzální_20funkce_20pro_20práci_20s_20iterátory_92',['5. Univerzální funkce pro práci s iterátory',['../group___iterator_algorithms.html',1,'']]]
];
