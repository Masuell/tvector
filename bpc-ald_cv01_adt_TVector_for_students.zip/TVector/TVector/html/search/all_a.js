var searchData=
[
  ['resize_5ftesting_15',['resize_testing',['../group___main_program.html#ga389209d8bde0a8922177efb8ed7a22a6',1,'main.c']]],
  ['reversed_5fdata_16',['reversed_data',['../md_reversed_data.html',1,'']]],
  ['reversed_5fdata_2etxt_17',['reversed_data.txt',['../reversed__data_8txt.html',1,'']]]
];
