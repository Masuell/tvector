var indexSectionsWithContent =
{
  0: "12345cdimprtvz",
  1: "t",
  2: "cmrt",
  3: "dmprv",
  4: "i",
  5: "t",
  6: "12345",
  7: "rz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Vše",
  1: "Datové struktury",
  2: "Soubory",
  3: "Funkce",
  4: "Proměnné",
  5: "Definice typů",
  6: "Skupiny",
  7: "Stránky"
};

