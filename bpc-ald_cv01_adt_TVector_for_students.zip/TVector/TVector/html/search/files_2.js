var searchData=
[
  ['reversed_5fdata_2etxt_53',['reversed_data.txt',['../reversed__data_8txt.html',1,'']]]
];
