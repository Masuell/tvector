var searchData=
[
  ['reversed_5fdata_93',['reversed_data',['../md_reversed_data.html',1,'']]]
];
